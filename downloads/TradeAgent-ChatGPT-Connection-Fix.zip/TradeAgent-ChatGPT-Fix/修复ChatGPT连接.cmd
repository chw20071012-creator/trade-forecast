@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0fix.ps1"
set "patch_exit=%ERRORLEVEL%"
pause
exit /b %patch_exit%
