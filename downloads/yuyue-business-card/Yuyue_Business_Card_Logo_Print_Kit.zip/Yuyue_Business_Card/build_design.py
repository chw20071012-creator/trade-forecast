from pathlib import Path
import json
import zipfile
from xml.sax.saxutils import escape

import fitz
import qrcode
import cairosvg
import zxingcpp
from PIL import Image
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.reportLabPen import ReportLabPen
from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColor
from reportlab.lib.units import mm

ROOT = Path(__file__).parent
NAVY = '#102A43'
INK = '#16324B'
MUTED = '#526777'
ICE = '#BDD4E6'
WHITE = '#FFFFFF'
QR_URL = 'https://wa.me/8619963321521'
fonts = {
    'regular': TTFont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
    'bold': TTFont('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
    'zh': TTFont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', fontNumber=2),
    'zhbold': TTFont('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', fontNumber=2),
}


class PDFPen(ReportLabPen):
    def _closePath(self):
        self.path.close()


def cmyk(hex_color):
    r, g, b = [int(hex_color[i:i+2], 16) / 255 for i in (1, 3, 5)]
    k = 1 - max(r, g, b)
    if k == 1:
        return CMYKColor(0, 0, 0, 1)
    return CMYKColor((1-r-k)/(1-k), (1-g-k)/(1-k), (1-b-k)/(1-k), k)


def metrics(text, size, font='regular'):
    f = fonts[font]
    cmap = f.getBestCmap()
    return sum(f['hmtx'][cmap[ord(ch)]][0] for ch in text) * size / f['head'].unitsPerEm


class Art:
    def __init__(self, pdf, w=90, h=54, bleed=3):
        self.pdf, self.w, self.h, self.bleed = pdf, w, h, bleed
        self.parts = []
        self.labels = []
        pdf.saveState()
        pdf.translate(bleed * mm, (h + bleed) * mm)
        pdf.scale(mm, -mm)

    def rect(self, x, y, w, h, fill):
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"/>')
        self.pdf.setFillColor(cmyk(fill))
        self.pdf.rect(x, y, w, h, fill=1, stroke=0)

    def polygon(self, points, fill):
        self.parts.append('<polygon points="' + ' '.join(f'{x},{y}' for x,y in points) + f'" fill="{fill}"/>')
        p = self.pdf.beginPath()
        p.moveTo(*points[0])
        for point in points[1:]:
            p.lineTo(*point)
        p.close()
        self.pdf.setFillColor(cmyk(fill))
        self.pdf.drawPath(p, fill=1, stroke=0)

    def text(self, x, y, text, size, fill=INK, font='regular', align='left', max_width=None):
        width = metrics(text, size, font)
        if max_width is not None:
            assert width <= max_width, (text, width, max_width)
        if align == 'center':
            x -= width / 2
        if align == 'right':
            x -= width
        assert x >= 0 and x + width <= self.w + .01, (text, x, width)
        self.labels.append({'text': text, 'x_mm': x, 'baseline_mm': y, 'font_size_pt': size*mm, 'width_mm': width})
        f = fonts[font]
        scale = size / f['head'].unitsPerEm
        glyphs, cmap = f.getGlyphSet(), f.getBestCmap()
        self.parts.append(f'<g aria-label="{escape(text)}" fill="{fill}" transform="translate({x},{y}) scale({scale}, {-scale})">')
        self.pdf.saveState()
        self.pdf.translate(x, y)
        self.pdf.scale(scale, -scale)
        self.pdf.setFillColor(cmyk(fill))
        offset = 0
        for ch in text:
            name = cmap[ord(ch)]
            pen = SVGPathPen(glyphs)
            glyphs[name].draw(pen)
            self.parts.append(f'<path transform="translate({offset},0)" d="{pen.getCommands()}"/>')
            pdf_pen = PDFPen(glyphs, self.pdf.beginPath())
            glyphs[name].draw(pdf_pen)
            self.pdf.saveState()
            self.pdf.translate(offset, 0)
            self.pdf.drawPath(pdf_pen.path, fill=1, stroke=0)
            self.pdf.restoreState()
            offset += f['hmtx'][name][0]
        self.pdf.restoreState()
        self.parts.append('</g>')

    def logo(self, x, y, width, fill=NAVY):
        # Two geometric Y initials: rising arms and aligned vertical stems.
        for shift in (0, 46):
            shape = [(0,0),(12,0),(24,16),(36,0),(48,0),(30,26),(30,58),(18,58),(18,26)]
            self.polygon([(x+(px+shift)*width/94, y+py*width/94) for px,py in shape], fill)

    def save(self, name, *, trim=False):
        self.pdf.restoreState()
        b = 0 if trim else self.bleed
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w+2*b}mm" height="{self.h+2*b}mm" viewBox="{-b} {-b} {self.w+2*b} {self.h+2*b}">' + ''.join(self.parts) + '</svg>'
        (ROOT/name).write_text(svg, encoding='utf-8')
        return svg


pdf = canvas.Canvas(str(ROOT/'Yuyue_Business_Card_PRINT_90x54mm.pdf'), pagesize=(96*mm,60*mm), pageCompression=1)
pdf.setTitle('Yuyue International Trading | Howard Chen | Business Card')
pdf.setAuthor('Yuyue International Trading Co., Ltd.')
pdf.setSubject('Two pages: front and back. 90 x 54 mm trim; 3 mm bleed; CMYK vector artwork; all type outlined.')
qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_Q, box_size=16, border=4)
qr.add_data(QR_URL)
qr.make(fit=True)
matrix = qr.get_matrix()
qr.make_image(fill_color='black', back_color='white').save(ROOT/'WhatsApp_QR.png')

front = Art(pdf)
front.rect(-3,-3,96,60,WHITE)
front.rect(-3,-3,5,60,NAVY)
front.logo(7,6.8,9.5)
front.text(19.2,10.1,'昱岳国际贸易有限公司',3.7,NAVY,'zhbold',max_width=65)
front.text(19.2,14.3,'Yuyue International Trading Co., Ltd.',2.35,MUTED,max_width=65)
front.text(7,21,'箱包 OEM 定制',2.8,INK,'zhbold')
front.rect(28.5,18.8,.25,2.5,ICE)
front.text(31,21,'CUSTOM BAG OEM',2.65,INK,'bold')
front.text(7,29.2,'Howard Chen',4.45,NAVY,'bold')
front.text(44,29.2,'陈灏文',3.0,INK,'zh')
front.text(7,33.8,'Founder',2.5,MUTED)
front.text(19.5,33.8,'创始人',2.5,MUTED,'zh')
front.rect(7,36,51,.18,ICE)
front.text(7,40.3,'WhatsApp  +86 199 6332 1521',2.45,INK,max_width=55)
front.text(7,44.7,'yuyueguojimaoyi2026@gmail.com',2.45,INK,max_width=55)
front.text(7,49.1,'WeChat  yuyue2026chw66',2.45,INK,max_width=55)
qr_x,qr_y,qr_size = 64.8,28.6,20.2
cell = qr_size/len(matrix)
for row,line in enumerate(matrix):
    for col,black in enumerate(line):
        if black:
            front.rect(qr_x+col*cell,qr_y+row*cell,cell,cell,'#000000')
front.text(qr_x+qr_size/2,51,'SCAN TO CHAT',2.05,MUTED,align='center')
front.save('Yuyue_Card_Front_Outlined_Bleed.svg')
front_labels=front.labels
pdf.setTrimBox((3*mm,3*mm,93*mm,57*mm))
pdf.setBleedBox((0,0,96*mm,60*mm))
pdf.showPage()

back = Art(pdf)
back.rect(-3,-3,96,60,NAVY)
back.text(7,8.5,'YUYUE INTERNATIONAL',2.35,ICE,'bold')
back.logo(74.8,5.5,9.5,WHITE)
back.text(7,16,'CUSTOM BAG OEM',4.4,WHITE,'bold')
back.text(7,21.1,'From your drawings or samples to finished bags.',2.4,ICE,max_width=78)
services = [
    'Drawing- & sample-based customization',
    'Sampling & small-batch production',
    'Custom logos, fabrics, colors & hardware',
    'Design support & structural refinement',
    'Inspection, packaging & shipping coordination',
]
for i,service in enumerate(services):
    y=28.7+i*5.0
    back.rect(7,y-1.4,1.2,1.2,ICE)
    back.text(10.5,y,service,2.55,WHITE,max_width=73)
back.save('Yuyue_Card_Back_Outlined_Bleed.svg')
back_labels=back.labels
pdf.setTrimBox((3*mm,3*mm,93*mm,57*mm))
pdf.setBleedBox((0,0,96*mm,60*mm))
pdf.showPage()
pdf.save()

# Logo master, transparent and outlined: suitable for cards, labels and email.
lp = canvas.Canvas(str(ROOT/'Yuyue_Logo_Vector.pdf'), pagesize=(108*mm,30*mm))
logo=Art(lp,108,30,0)
logo.logo(3,6,21)
logo.text(30,13.8,'YUYUE',10,NAVY,'bold')
logo.text(30,20,'昱岳国际贸易',3.4,NAVY,'zh')
logo.text(30,25,'INTERNATIONAL TRADING',2.7,MUTED,'regular')
svg=logo.save('Yuyue_Logo_Outlined.svg')
lp.save()
cairosvg.svg2png(bytestring=svg.encode(),write_to=str(ROOT/'Yuyue_Logo_Transparent.png'),output_width=1800,output_height=500)

# Flat proof board: separate from production files; no altered contact details.
board = canvas.Canvas(str(ROOT/'Yuyue_Design_Proof.pdf'), pagesize=(240*mm,178*mm))
art=Art(board,240,178,0)
art.rect(0,0,240,178,'#EDF1F4')
art.text(15,15,'YUYUE',5.5,NAVY,'bold')
art.text(15,23,'品牌标志与双面名片',3.5,MUTED,'zh')
art.logo(15,35,24)
art.text(46,45,'YUYUE INTERNATIONAL',5,NAVY,'bold')
art.text(46,52,'昱岳国际贸易有限公司',3.5,INK,'zh')
art.text(15,69,'FRONT / 正面',2.8,MUTED,'zh')
art.text(133,69,'BACK / 背面',2.8,MUTED,'zh')
# Place the exact production pages at 1.08x in the proof via PyMuPDF below.
art.text(15,151,'90 × 54 mm  ·  3 mm bleed  ·  Navy & White',3.0,MUTED)
art.text(15,160,'WhatsApp QR links directly to +86 199 6332 1521',2.8,MUTED)
art.save('Yuyue_Proof_Base.svg')
board.save()
proof=fitz.open(ROOT/'Yuyue_Design_Proof.pdf')
cards=fitz.open(ROOT/'Yuyue_Business_Card_PRINT_90x54mm.pdf')
for i,x in enumerate([15,133]):
    dest=fitz.Rect(x*mm,76*mm,(x+92)*mm,(76+55.2)*mm)
    proof[0].show_pdf_page(dest,cards,i,clip=fitz.Rect(3*mm,3*mm,93*mm,57*mm))
proof.save(ROOT/'Yuyue_Design_Proof_Final.pdf')
proof[0].get_pixmap(matrix=fitz.Matrix(2.8,2.8),alpha=False).save(ROOT/'Yuyue_Design_Proof.png')
proof.close()
for i,name in enumerate(['Front','Back']):
    cards[i].get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=fitz.Rect(3*mm,3*mm,93*mm,57*mm),alpha=False).save(ROOT/f'Yuyue_Card_{name}_600dpi.png')
    assert abs(cards[i].trimbox.width/mm-90)<.01
    assert abs(cards[i].trimbox.height/mm-54)<.01
    assert not cards[i].get_text().strip(), 'Visible lettering must be outlined'

decoded=zxingcpp.read_barcodes(Image.open(ROOT/'Yuyue_Card_Front_600dpi.png'))
assert len(decoded)==1 and decoded[0].text==QR_URL, decoded
small=cards[0].get_pixmap(matrix=fitz.Matrix(300/72,300/72),clip=fitz.Rect(3*mm,3*mm,93*mm,57*mm),alpha=False)
decoded300=zxingcpp.read_barcodes(Image.frombytes('RGB',(small.width,small.height),small.samples))
assert len(decoded300)==1 and decoded300[0].text==QR_URL
cards.close()

spec = {'company_zh':'昱岳国际贸易有限公司','company_en':'Yuyue International Trading Co., Ltd.',
        'person_zh':'陈灏文','person_en':'Howard Chen','title':'Founder',
        'email':'yuyueguojimaoyi2026@gmail.com','whatsapp':'+86 19963321521',
        'wechat':'yuyue2026chw66','qr_url':QR_URL,'trim_mm':[90,54],'bleed_mm':3,
        'pdf_pages':['front','back'],'front_text':front_labels,'back_text':back_labels,
        'qr_decoded_600dpi':decoded[0].text,'qr_decoded_300dpi':decoded300[0].text,
        'minimum_contact_type_pt':2.45*mm,'qr_size_mm':qr_size,'qr_error_correction':'Q',
        'pdf_color':'CMYK vector artwork','pdf_type':'outlined lettering, no external fonts',
        'logo_note':'Original geometric double-Y concept; no trademark clearance performed.'}
(ROOT/'design-spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'印刷与使用说明.txt').write_text('''昱岳国际贸易有限公司｜名片交付说明

印刷文件：Yuyue_Business_Card_PRINT_90x54mm.pdf
共两页：第1页正面，第2页背面；均为横向阅读。
成品90×54mm；四边各3mm出血，页面96×60mm。
已设置TrimBox、BleedBox；请按100%原尺寸印刷，不要适应页面缩放。
文件为CMYK矢量图文；全部文字已转曲，无需另外安装字体。
请印厂按裁切框拼版并核对双面朝向。SVG为RGB转曲源稿，印刷优先使用PDF。
建议350g白卡、双面哑膜、直角裁切；请先做一张实物打样，核对深蓝颜色、小字和二维码。
屏幕与印刷颜色存在差异，颜色以实物打样为准。

Logo：Yuyue_Logo_Outlined.svg（透明矢量）、Yuyue_Logo_Vector.pdf、Yuyue_Logo_Transparent.png。
名片平面图：Front/Back_600dpi.png。效果总览：Yuyue_Design_Proof.png。
生产文件包含用户确认的姓名、公司名、邮箱、WhatsApp和微信号；无地址、网址或产品图片。
二维码实际地址：https://wa.me/8619963321521
已从整张名片300dpi及600dpi渲染图中成功识别并核对链接；未发送消息。
WhatsApp账号可用性仍以手机实际打开结果为准。

业务英文对应：
Drawing- & sample-based customization：来图／来样定制
Sampling & small-batch production：打样与小批量生产
Custom logos, fabrics, colors & hardware：Logo、面料、颜色与配件定制
Design support & structural refinement：产品设计协助与结构优化
Inspection, packaging & shipping coordination：验货、包装及运输协调

没有添加未确认的认证、工厂规模、最低订单量或交期承诺。
Logo为本次设计的双Y字母标；如用于商标注册，请另做商标检索。
''',encoding='utf-8')
print(json.dumps({'output':str(ROOT),'qr_300dpi':'PASS','qr_600dpi':'PASS','trim_box':'90 x 54 mm','fonts':'outlined'},ensure_ascii=False))
